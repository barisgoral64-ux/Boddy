package com.example.bodytracker.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "patients")
data class PatientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val firstName: String,
    val lastName: String,
    val birthDate: String,
    val gender: String,
    val heightCm: Int,
    val photoUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "measurements",
    foreignKeys = [
        ForeignKey(
            entity = PatientEntity::class,
            parentColumns = ["id"],
            childColumns = ["patientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("patientId")]
)
data class MeasurementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val patientId: Long,
    val date: String,
    val weightKg: Double,
    val bmi: Double,
    val bodyFatPercent: Double,
    val bodyWaterPercent: Double,
    val muscle: Double,
    val physicalActivity: Double,
    val bone: Double,
    val metabolicRate: Double,
    val metabolicAge: Int,
    val visceralFat: Double,
    val createdAt: Long = System.currentTimeMillis()
)

data class PatientWithLatestMeasurement(
    val patient: PatientEntity,
    val latestMeasurement: MeasurementEntity?
)

data class ComparisonRow(
    val label: String,
    val current: String,
    val previous: String,
    val difference: String
)
