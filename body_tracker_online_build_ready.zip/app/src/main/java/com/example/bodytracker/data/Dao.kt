package com.example.bodytracker.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PatientDao {
    @Query("SELECT * FROM patients ORDER BY createdAt DESC")
    fun observePatients(): Flow<List<PatientEntity>>

    @Query("SELECT * FROM patients WHERE id = :patientId")
    fun observePatient(patientId: Long): Flow<PatientEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(patient: PatientEntity): Long
}

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM measurements WHERE patientId = :patientId ORDER BY date DESC, createdAt DESC")
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>>

    @Query("SELECT * FROM measurements ORDER BY date DESC, createdAt DESC")
    fun observeAllMeasurements(): Flow<List<MeasurementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(measurement: MeasurementEntity): Long
}
