package com.example.bodytracker.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bodytracker.viewmodel.HomeUiState
import com.example.bodytracker.viewmodel.PatientCardUi

@Composable
fun PatientListScreen(
    state: HomeUiState,
    onAddPatient: () -> Unit,
    onPatientClick: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hasta Listesi", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = onAddPatient, modifier = Modifier.fillMaxWidth()) {
            Text("Yeni Hasta Ekle")
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(state.patients) { patient ->
                PatientListCard(patient = patient, onClick = { onPatientClick(patient.id) })
            }
        }
    }
}

@Composable
private fun PatientListCard(patient: PatientCardUi, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(patient.fullName, style = MaterialTheme.typography.titleLarge)
            Text("Doğum: ${patient.birthDate} · Yaş: ${patient.age}")
            Text("Boy: ${patient.heightCm} cm")
            Text("Son kilo: ${patient.lastWeight} · Son VKİ: ${patient.lastBmi}")
            Text("Son ölçüm: ${patient.lastMeasurementDate}")
        }
    }
}
