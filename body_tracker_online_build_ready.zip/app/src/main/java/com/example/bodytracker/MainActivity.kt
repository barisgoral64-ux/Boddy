package com.example.bodytracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.bodytracker.data.MeasurementInput
import com.example.bodytracker.ui.screens.AddMeasurementScreen
import com.example.bodytracker.ui.screens.AddPatientScreen
import com.example.bodytracker.ui.screens.PatientDetailScreen
import com.example.bodytracker.ui.screens.PatientListScreen
import com.example.bodytracker.ui.theme.BodyTrackerTheme
import com.example.bodytracker.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BodyTrackerTheme {
                BodyTrackerApp(viewModel)
            }
        }
    }
}

@Composable
fun BodyTrackerApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val homeState = viewModel.homeUiState.collectAsStateWithLifecycle()
    val detailState = viewModel.patientDetailUiState.collectAsStateWithLifecycle()

    Scaffold { innerPadding ->
        NavHost(navController = navController, startDestination = "patients", modifier = Modifier.padding(innerPadding)) {
            composable("patients") {
                PatientListScreen(
                    state = homeState.value,
                    onAddPatient = { navController.navigate("add_patient") },
                    onPatientClick = { id ->
                        viewModel.selectPatient(id)
                        navController.navigate("patient/$id")
                    }
                )
            }
            composable("add_patient") {
                AddPatientScreen(
                    onSave = { firstName, lastName, birthDate, gender, heightCm, photoUri ->
                        viewModel.addPatient(firstName, lastName, birthDate, gender, heightCm, photoUri)
                        navController.popBackStack()
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = "patient/{patientId}",
                arguments = listOf(navArgument("patientId") { type = NavType.LongType })
            ) {
                PatientDetailScreen(
                    state = detailState.value,
                    onBack = { navController.popBackStack() },
                    onAddMeasurement = {
                        navController.navigate("add_measurement")
                    }
                )
            }
            composable("add_measurement") {
                AddMeasurementScreen(
                    onSave = { input: MeasurementInput ->
                        viewModel.addMeasurement(input)
                        navController.popBackStack()
                    },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
