package com.example.bodytracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bodytracker.data.AppDatabase
import com.example.bodytracker.data.BodyRepository
import com.example.bodytracker.data.ComparisonRow
import com.example.bodytracker.data.MeasurementEntity
import com.example.bodytracker.data.MeasurementInput
import com.example.bodytracker.data.PatientEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class HomeUiState(
    val patients: List<PatientCardUi> = emptyList()
)

data class PatientCardUi(
    val id: Long,
    val fullName: String,
    val birthDate: String,
    val age: Int,
    val heightCm: Int,
    val photoUri: String?,
    val lastWeight: String,
    val lastBmi: String,
    val lastMeasurementDate: String
)

data class PatientDetailUiState(
    val patient: PatientEntity? = null,
    val measurements: List<MeasurementEntity> = emptyList(),
    val comparisonRows: List<ComparisonRow> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repository = BodyRepository(db.patientDao(), db.measurementDao())

    private val _homeUiState = MutableStateFlow(HomeUiState())
    val homeUiState: StateFlow<HomeUiState> = _homeUiState.asStateFlow()

    private val _patientDetailUiState = MutableStateFlow(PatientDetailUiState())
    val patientDetailUiState: StateFlow<PatientDetailUiState> = _patientDetailUiState.asStateFlow()

    private var detailJob: Job? = null

    init {
        viewModelScope.launch {
            repository.observePatientsWithLatest().collect { patients ->
                _homeUiState.value = HomeUiState(
                    patients = patients.map { item ->
                        val patient = item.patient
                        PatientCardUi(
                            id = patient.id,
                            fullName = "${patient.firstName} ${patient.lastName}",
                            birthDate = patient.birthDate,
                            age = repository.calculateAge(patient.birthDate),
                            heightCm = patient.heightCm,
                            photoUri = patient.photoUri,
                            lastWeight = item.latestMeasurement?.weightKg?.let { "$it kg" } ?: "-",
                            lastBmi = item.latestMeasurement?.bmi?.toString() ?: "-",
                            lastMeasurementDate = item.latestMeasurement?.date ?: "Ölçüm yok"
                        )
                    }
                )
            }
        }
    }

    fun selectPatient(patientId: Long) {
        detailJob?.cancel()
        detailJob = viewModelScope.launch {
            repository.observePatient(patientId)
                .combine(repository.observeMeasurements(patientId)) { patient, measurements ->
                    val current = measurements.getOrNull(0)
                    val previous = measurements.getOrNull(1)
                    PatientDetailUiState(
                        patient = patient,
                        measurements = measurements,
                        comparisonRows = if (current != null) repository.buildComparisonRows(current, previous) else emptyList()
                    )
                }
                .collect { _patientDetailUiState.value = it }
        }
    }

    fun addSampleDataIfNeeded() {
        if (_homeUiState.value.patients.isNotEmpty()) return
        viewModelScope.launch {
            val patientId = repository.addPatient(
                PatientEntity(
                    firstName = "Ayşe",
                    lastName = "Demir",
                    birthDate = "1992-05-14",
                    gender = "Kadın",
                    heightCm = 168,
                    photoUri = null
                )
            )
            repository.addMeasurement(
                patientId,
                168,
                MeasurementInput(
                    date = "2026-02-20",
                    weightKg = 72.4,
                    bodyFatPercent = 28.0,
                    bodyWaterPercent = 49.0,
                    muscle = 26.2,
                    physicalActivity = 3.0,
                    bone = 2.6,
                    metabolicRate = 1420.0,
                    metabolicAge = 33,
                    visceralFat = 7.0
                )
            )
            repository.addMeasurement(
                patientId,
                168,
                MeasurementInput(
                    date = "2026-03-20",
                    weightKg = 70.8,
                    bodyFatPercent = 26.5,
                    bodyWaterPercent = 50.1,
                    muscle = 26.9,
                    physicalActivity = 4.0,
                    bone = 2.7,
                    metabolicRate = 1460.0,
                    metabolicAge = 31,
                    visceralFat = 6.0
                )
            )
        }
    }

    fun addPatient(
        firstName: String,
        lastName: String,
        birthDate: String,
        gender: String,
        heightCm: Int,
        photoUri: String?
    ) {
        viewModelScope.launch {
            repository.addPatient(
                PatientEntity(
                    firstName = firstName,
                    lastName = lastName,
                    birthDate = birthDate,
                    gender = gender,
                    heightCm = heightCm,
                    photoUri = photoUri
                )
            )
        }
    }

    fun addMeasurement(input: MeasurementInput) {
        val patient = _patientDetailUiState.value.patient ?: return
        viewModelScope.launch {
            repository.addMeasurement(patient.id, patient.heightCm, input)
        }
    }
}
