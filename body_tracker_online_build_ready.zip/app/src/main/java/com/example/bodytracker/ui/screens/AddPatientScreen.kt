package com.example.bodytracker.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AddPatientScreen(
    onSave: (String, String, String, String, Int, String?) -> Unit,
    onBack: () -> Unit
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("1990-01-01") }
    var gender by remember { mutableStateOf("Kadın") }
    var heightCm by remember { mutableStateOf("170") }
    var photoUri by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Yeni Hasta", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(value = firstName, onValueChange = { firstName = it }, label = { Text("Ad") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = lastName, onValueChange = { lastName = it }, label = { Text("Soyad") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = birthDate, onValueChange = { birthDate = it }, label = { Text("Doğum Tarihi (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = gender, onValueChange = { gender = it }, label = { Text("Cinsiyet") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = heightCm, onValueChange = { heightCm = it }, label = { Text("Boy (cm)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = photoUri, onValueChange = { photoUri = it }, label = { Text("Fotoğraf URI") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { onSave(firstName, lastName, birthDate, gender, heightCm.toIntOrNull() ?: 0, photoUri.ifBlank { null }) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Kaydet") }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Geri") }
    }
}
