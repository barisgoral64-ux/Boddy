package com.example.bodytracker.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bodytracker.ui.components.ComparisonCard
import com.example.bodytracker.ui.components.MetricCard
import com.example.bodytracker.viewmodel.PatientDetailUiState

@Composable
fun PatientDetailScreen(
    state: PatientDetailUiState,
    onBack: () -> Unit,
    onAddMeasurement: () -> Unit
) {
    val patient = state.patient
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(patient?.let { "${it.firstName} ${it.lastName}" } ?: "Hasta", style = MaterialTheme.typography.headlineMedium)
            Text(patient?.let { "Doğum: ${it.birthDate} · Boy: ${it.heightCm} cm" } ?: "")
        }
        item {
            Button(onClick = onAddMeasurement, modifier = Modifier.fillMaxWidth()) { Text("Yeni Ölçüm Ekle") }
        }
        state.measurements.firstOrNull()?.let { last ->
            item { Text("Son Ölçüm", style = MaterialTheme.typography.titleLarge) }
            item { MetricCard("Kilo", "${last.weightKg} kg", "Tarih: ${last.date}") }
            item { MetricCard("VKİ", last.bmi.toString()) }
            item { MetricCard("Vücut Yağ Oranı", "${last.bodyFatPercent} %") }
            item { MetricCard("Vücut Sıvı Oranı", "${last.bodyWaterPercent} %") }
            item { MetricCard("Kas", "${last.muscle} kg") }
            item { MetricCard("Fiziksel Aktivite", last.physicalActivity.toString()) }
            item { MetricCard("Kemik", "${last.bone} kg") }
            item { MetricCard("Metabolizma Hızı", "${last.metabolicRate} kcal") }
            item { MetricCard("Metabolizma Yaşı", last.metabolicAge.toString()) }
            item { MetricCard("İç Yağ", last.visceralFat.toString()) }
        }
        if (state.comparisonRows.isNotEmpty()) {
            item { Text("Önceki Ölçüm ile Karşılaştırma", style = MaterialTheme.typography.titleLarge) }
            items(state.comparisonRows) { row ->
                ComparisonCard(row.label, row.current, row.previous, row.difference)
            }
        }
        if (state.measurements.isNotEmpty()) {
            item { Text("Ölçüm Geçmişi", style = MaterialTheme.typography.titleLarge) }
            items(state.measurements) { m ->
                MetricCard("${m.date}", "${m.weightKg} kg · VKİ ${m.bmi}", "Yağ ${m.bodyFatPercent}% · Kas ${m.muscle} kg")
            }
        }
        item {
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Geri") }
        }
    }
}
