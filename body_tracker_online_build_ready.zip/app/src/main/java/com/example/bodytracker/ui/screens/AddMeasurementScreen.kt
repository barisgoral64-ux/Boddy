package com.example.bodytracker.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bodytracker.data.MeasurementInput

@Composable
fun AddMeasurementScreen(
    onSave: (MeasurementInput) -> Unit,
    onBack: () -> Unit
) {
    var date by remember { mutableStateOf("2026-03-28") }
    var weightKg by remember { mutableStateOf("") }
    var bodyFatPercent by remember { mutableStateOf("") }
    var bodyWaterPercent by remember { mutableStateOf("") }
    var muscle by remember { mutableStateOf("") }
    var physicalActivity by remember { mutableStateOf("") }
    var bone by remember { mutableStateOf("") }
    var metabolicRate by remember { mutableStateOf("") }
    var metabolicAge by remember { mutableStateOf("") }
    var visceralFat by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Yeni Ölçüm", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Tarih") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = weightKg, onValueChange = { weightKg = it }, label = { Text("Kilo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = bodyFatPercent, onValueChange = { bodyFatPercent = it }, label = { Text("Vücut Yağ Oranı") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = bodyWaterPercent, onValueChange = { bodyWaterPercent = it }, label = { Text("Vücut Sıvı Oranı") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = muscle, onValueChange = { muscle = it }, label = { Text("Kas") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = physicalActivity, onValueChange = { physicalActivity = it }, label = { Text("Fiziksel Aktivite") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = bone, onValueChange = { bone = it }, label = { Text("Kemik") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = metabolicRate, onValueChange = { metabolicRate = it }, label = { Text("Metabolizma Hızı") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = metabolicAge, onValueChange = { metabolicAge = it }, label = { Text("Metabolizma Yaşı") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = visceralFat, onValueChange = { visceralFat = it }, label = { Text("İç Yağ") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                onSave(
                    MeasurementInput(
                        date = date,
                        weightKg = weightKg.toDoubleOrNull() ?: 0.0,
                        bodyFatPercent = bodyFatPercent.toDoubleOrNull() ?: 0.0,
                        bodyWaterPercent = bodyWaterPercent.toDoubleOrNull() ?: 0.0,
                        muscle = muscle.toDoubleOrNull() ?: 0.0,
                        physicalActivity = physicalActivity.toDoubleOrNull() ?: 0.0,
                        bone = bone.toDoubleOrNull() ?: 0.0,
                        metabolicRate = metabolicRate.toDoubleOrNull() ?: 0.0,
                        metabolicAge = metabolicAge.toIntOrNull() ?: 0,
                        visceralFat = visceralFat.toDoubleOrNull() ?: 0.0
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Kaydet") }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Geri") }
    }
}
