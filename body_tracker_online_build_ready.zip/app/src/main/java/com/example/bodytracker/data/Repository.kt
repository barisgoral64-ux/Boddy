package com.example.bodytracker.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.LocalDate
import java.time.Period
import kotlin.math.pow
import kotlin.math.round

class BodyRepository(
    private val patientDao: PatientDao,
    private val measurementDao: MeasurementDao
) {
    fun observePatientsWithLatest(): Flow<List<PatientWithLatestMeasurement>> {
        return combine(patientDao.observePatients(), measurementDao.observeAllMeasurements()) { patients, measurements ->
            patients.map { patient ->
                val latest = measurements
                    .filter { it.patientId == patient.id }
                    .maxByOrNull { it.date + "-" + it.createdAt }
                PatientWithLatestMeasurement(patient, latest)
            }
        }
    }

    fun observePatient(patientId: Long): Flow<PatientEntity?> = patientDao.observePatient(patientId)

    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>> =
        measurementDao.observeMeasurements(patientId)

    suspend fun addPatient(patient: PatientEntity): Long = patientDao.insert(patient)

    suspend fun addMeasurement(patientId: Long, patientHeightCm: Int, input: MeasurementInput): Long {
        val bmi = calculateBmi(input.weightKg, patientHeightCm)
        return measurementDao.insert(
            MeasurementEntity(
                patientId = patientId,
                date = input.date,
                weightKg = input.weightKg,
                bmi = bmi,
                bodyFatPercent = input.bodyFatPercent,
                bodyWaterPercent = input.bodyWaterPercent,
                muscle = input.muscle,
                physicalActivity = input.physicalActivity,
                bone = input.bone,
                metabolicRate = input.metabolicRate,
                metabolicAge = input.metabolicAge,
                visceralFat = input.visceralFat
            )
        )
    }

    fun buildComparisonRows(current: MeasurementEntity, previous: MeasurementEntity?): List<ComparisonRow> {
        if (previous == null) return emptyList()
        return listOf(
            compare("Kilo", current.weightKg, previous.weightKg, "kg"),
            compare("VKİ", current.bmi, previous.bmi, ""),
            compare("Yağ Oranı", current.bodyFatPercent, previous.bodyFatPercent, "%"),
            compare("Sıvı Oranı", current.bodyWaterPercent, previous.bodyWaterPercent, "%"),
            compare("Kas", current.muscle, previous.muscle, "kg"),
            compare("Fiziksel Aktivite", current.physicalActivity, previous.physicalActivity, ""),
            compare("Kemik", current.bone, previous.bone, "kg"),
            compare("Metabolizma Hızı", current.metabolicRate, previous.metabolicRate, "kcal"),
            compare("Metabolizma Yaşı", current.metabolicAge.toDouble(), previous.metabolicAge.toDouble(), ""),
            compare("İç Yağ", current.visceralFat, previous.visceralFat, "")
        )
    }

    fun calculateAge(birthDate: String): Int {
        return try {
            Period.between(LocalDate.parse(birthDate), LocalDate.now()).years
        } catch (_: Exception) {
            0
        }
    }

    private fun calculateBmi(weightKg: Double, heightCm: Int): Double {
        val heightM = heightCm / 100.0
        return round(weightKg / heightM.pow(2) * 10) / 10
    }

    private fun compare(label: String, current: Double, previous: Double, unit: String): ComparisonRow {
        val diff = round((current - previous) * 10) / 10
        val prefix = if (diff > 0) "+" else ""
        val suffix = if (unit.isBlank()) "" else " $unit"
        return ComparisonRow(
            label = label,
            current = "$current$suffix",
            previous = "$previous$suffix",
            difference = "$prefix$diff$suffix"
        )
    }
}

data class MeasurementInput(
    val date: String,
    val weightKg: Double,
    val bodyFatPercent: Double,
    val bodyWaterPercent: Double,
    val muscle: Double,
    val physicalActivity: Double,
    val bone: Double,
    val metabolicRate: Double,
    val metabolicAge: Int,
    val visceralFat: Double
)
