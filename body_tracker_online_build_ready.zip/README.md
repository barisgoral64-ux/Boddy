# Body Tracker Android

Bu proje, hasta bazlı vücut analiz takibi için Kotlin + Jetpack Compose + Room altyapısı ile hazırlanmış başlangıç uygulamasıdır.

## Özellikler
- Hasta kaydı: ad, soyad, doğum tarihi, cinsiyet, boy, fotoğraf URI
- Ölçüm kaydı: kilo, VKİ, vücut yağ oranı, vücut sıvı oranı, kas, fiziksel aktivite, kemik, metabolizma hızı, metabolizma yaşı, iç yağ
- Tarih bazlı saklama
- Son ölçüm ve önceki ölçüm karşılaştırması
- Örnek veri ile açılış

## Ekranlar
1. Hasta Listesi
2. Yeni Hasta Ekle
3. Hasta Detay
4. Yeni Ölçüm Ekle

## Notlar
- Yaş doğum tarihinden hesaplanır.
- VKİ, boy ve kilo üzerinden otomatik hesaplanır.
- Fotoğraf alanı şu anda URI tabanlıdır. Bir sonraki sürümde galeri/kamera seçici eklenmelidir.
- Karşılaştırma mantığı şu anda son ölçüm ile bir önceki ölçümü kıyaslar. İstenirse ayrıca "önceki ay" filtresi kolayca eklenebilir.

## Bir sonraki sürüm için öneriler
- Gerçek tarih seçici
- Galeri/kamera entegrasyonu
- Grafik ekranları
- PDF rapor alma
- Ölçüm düzenleme/silme
- Arama ve filtreleme
