# Telefonda APK alma (GitHub Actions)

Bu paket, APK üretmeye hazır hale getirildi.

## Adımlar
1. GitHub'da yeni bir repo aç.
2. Bu klasördeki tüm dosyaları repoya yükle.
3. GitHub'da **Actions** sekmesine gir.
4. **Build APK** iş akışını seç.
5. **Run workflow** düğmesine bas.
6. İşlem bitince **Artifacts** altında `body-tracker-debug-apk` dosyasını indir.
7. ZIP içinden `app-debug.apk` dosyasını telefona kur.

## Not
- Bu bir debug APK'dır ve telefona doğrudan kurulabilir.
- Play Store'a yüklemek için release signing gerekir.
