# Tasarım Şeması

## Görsel Dil
- Klinik ve sade görünüm
- Açık arka plan
- Kart tabanlı veri gösterimi
- Büyük sayı, küçük açıklama mantığı

## Ana Sayfa
- Başlık: Hasta Listesi
- Üstte "Yeni Hasta Ekle" butonu
- Altta hasta kartları
- Kart içinde: ad soyad, doğum tarihi, yaş, boy, son kilo, son VKİ, son ölçüm tarihi

## Hasta Detay
- Üst bölüm: temel profil özeti
- Bölüm 1: son ölçüm kartları
- Bölüm 2: önceki ölçüme göre karşılaştırma kartları
- Bölüm 3: ölçüm geçmişi listesi

## Yeni Ölçüm
- Tek kolon form
- Her metrik için ayrı giriş alanı
- Kaydet ile veritabanına tarih bazlı kayıt

## Renk Mantığı
- Ana ton: mavi / turkuaz
- İyi yönde değişim: yeşil
- Kötü yönde değişim: kırmızı
- Nötr bilgiler: gri
