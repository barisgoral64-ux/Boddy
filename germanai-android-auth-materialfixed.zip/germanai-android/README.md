# GermanAI Android MVP

Bu proje Kotlin + Jetpack Compose ile hazırlanmış Android MVP iskeletidir.

## Bu sürümde olanlar
- Giriş yap ekranı
- Kayıt ol ekranı
- Lokal demo kullanıcı sistemi
- Ana sayfa
- Konuşma ekranı
- Dinleme ekranı
- Test ekranı
- Premium ekranı

## Demo hesap
- Kullanıcı adı: `demo`
- E-posta: `demo@germanai.app`
- Şifre: `123456`

## Notlar
- Bu auth sistemi şu an lokal ve demo amaçlıdır.
- Sonraki adımda Firebase Auth veya Supabase Auth bağlanabilir.
- STT/TTS ve gerçek AI entegrasyonu henüz bağlı değil; ekran akışı hazır.
- Google Play Billing henüz bağlı değil; sadece premium ekranı hazır.

## Sonraki önerilen adımlar
1. Firebase/Supabase auth ekleme
2. Room veya DataStore ile oturum saklama
3. OpenAI tabanlı AI öğretmen servisi
4. Android speech-to-text ve text-to-speech entegrasyonu
5. Google Play Billing abonelik sistemi
