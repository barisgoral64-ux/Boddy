package com.example.germanai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.germanai.ui.theme.GermanAITheme

data class LocalUser(val username: String, val email: String, val password: String)

enum class AppTab(val title: String) {
    HOME("Ana Sayfa"),
    SPEAK("Konuş"),
    LISTEN("Dinle"),
    TEST("Test"),
    PREMIUM("Premium")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GermanAITheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    GermanAiApp()
                }
            }
        }
    }
}

@Composable
fun GermanAiApp() {
    val users = remember {
        mutableStateListOf(
            LocalUser("demo", "demo@germanai.app", "123456")
        )
    }
    var currentUser by remember { mutableStateOf<LocalUser?>(null) }
    var authMode by rememberSaveable { mutableStateOf("login") }

    if (currentUser == null) {
        AuthScreen(
            authMode = authMode,
            onSwitchMode = { authMode = it },
            onRegister = { username, email, password ->
                val existing = users.any { it.email.equals(email, true) || it.username.equals(username, true) }
                if (existing) {
                    "Bu kullanıcı adı veya e-posta zaten kayıtlı."
                } else {
                    val newUser = LocalUser(username.trim(), email.trim(), password)
                    users.add(newUser)
                    currentUser = newUser
                    null
                }
            },
            onLogin = { emailOrUsername, password ->
                val found = users.firstOrNull {
                    (it.email.equals(emailOrUsername.trim(), true) || it.username.equals(emailOrUsername.trim(), true)) &&
                        it.password == password
                }
                if (found != null) {
                    currentUser = found
                    null
                } else {
                    "Kullanıcı adı/e-posta veya şifre hatalı."
                }
            }
        )
    } else {
        MainAppScaffold(user = currentUser!!, onLogout = { currentUser = null })
    }
}

@Composable
fun AuthScreen(
    authMode: String,
    onSwitchMode: (String) -> Unit,
    onRegister: (String, String, String) -> String?,
    onLogin: (String, String) -> String?
) {
    var username by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var errorMessage by rememberSaveable { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF7F8FA), Color.White)))
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101828)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("GermanAI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    if (authMode == "login") "Hesabınla giriş yap" else "Yeni hesap oluştur",
                    color = Color(0xFFD0D5DD)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Demo hesap: demo / 123456",
                    color = Color(0xFF98A2B3),
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (authMode == "register") {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Kullanıcı adı") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                singleLine = true
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(if (authMode == "login") "Kullanıcı adı veya e-posta" else "E-posta") },
            leadingIcon = { Icon(if (authMode == "login") Icons.Default.Person else Icons.Default.Email, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Şifre") },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                errorMessage = when (authMode) {
                    "register" -> {
                        if (username.isBlank() || email.isBlank() || password.length < 6) {
                            "Kullanıcı adı ve e-posta boş olamaz. Şifre en az 6 karakter olmalı."
                        } else {
                            onRegister(username, email, password)
                        }
                    }
                    else -> {
                        if (email.isBlank() || password.isBlank()) {
                            "Lütfen kullanıcı adı/e-posta ve şifre gir."
                        } else {
                            onLogin(email, password)
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (authMode == "login") "Giriş Yap" else "Kayıt Ol")
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text(
                if (authMode == "login") "Hesabın yok mu? " else "Zaten hesabın var mı? "
            )
            Text(
                if (authMode == "login") "Kayıt ol" else "Giriş yap",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable {
                    errorMessage = null
                    username = ""
                    email = ""
                    password = ""
                    onSwitchMode(if (authMode == "login") "register" else "login")
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(user: LocalUser, onLogout: () -> Unit) {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.HOME) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GermanAI", fontWeight = FontWeight.Bold)
                        Text("Merhaba, ${user.username}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    Button(onClick = onLogout, modifier = Modifier.padding(end = 12.dp)) {
                        Icon(Icons.Default.Logout, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Çıkış")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                listOf(AppTab.HOME, AppTab.SPEAK, AppTab.LISTEN, AppTab.TEST, AppTab.PREMIUM).forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            when (tab) {
                                AppTab.HOME -> Icon(Icons.Default.Home, contentDescription = null)
                                AppTab.SPEAK -> Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                                AppTab.LISTEN -> Icon(Icons.Default.VolumeUp, contentDescription = null)
                                AppTab.TEST -> Icon(Icons.Default.Quiz, contentDescription = null)
                                AppTab.PREMIUM -> Icon(Icons.Default.Diamond, contentDescription = null)
                            }
                        },
                        label = { Text(tab.title) }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                AppTab.HOME -> HomeScreen(user.username)
                AppTab.SPEAK -> SpeakScreen()
                AppTab.LISTEN -> ListenScreen()
                AppTab.TEST -> TestScreen()
                AppTab.PREMIUM -> PremiumScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(username: String) {
    val lessonItems = listOf(
        "Kendini tanıt" to "A1",
        "Markette konuş" to "A1",
        "Doktordan randevu al" to "A2",
        "Ev kiralama konuşması" to "B1"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Color(0xFF101828), Color(0xFF344054))))
                        .padding(20.dp)
                ) {
                    Column {
                        Text("Bugünkü hedef", color = Color(0xFFD0D5DD), fontSize = 13.sp)
                        Text("Hoş geldin, $username", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("15 dakika Almanca • Seviye A2 → B1", color = Color(0xFFEAECF0))
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                SmallActionCard("AI Öğretmen", Icons.Default.School, Modifier.weight(1f))
                SmallActionCard("Konuşma", Icons.Default.RecordVoiceOver, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                SmallActionCard("Dinleme", Icons.Default.Mic, Modifier.weight(1f))
                SmallActionCard("Mini Test", Icons.Default.Quiz, Modifier.weight(1f))
            }
        }
        item { Text("Bugünkü plan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(lessonItems) { lesson ->
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FC))) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(lesson.first, fontWeight = FontWeight.SemiBold)
                        Text("Yaklaşık 6 dk", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    AssistChip(onClick = {}, label = { Text(lesson.second) })
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun SmallActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(Color(0xFFF2F4F7), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Hızlı erişim", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
fun SpeakScreen() {
    var recording by rememberSaveable { mutableStateOf(false) }
    val scenarios = listOf("Markette fiyat sorma", "Doktor randevusu", "Otobüs bileti alma", "Ev sahibiyle konuşma")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F766E))) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("AI Konuşma Partneri", color = Color(0xFFCCFBF1), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Türkçe konuş, Almanca öğren", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Sonraki sürümde gerçek STT/TTS bağlanacak. Bu ekranda akış hazır.", color = Color.White)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Örnek çıktı", fontWeight = FontWeight.Bold)
                    Text("Türkçe: Yarın doktora gitmem gerekiyor")
                    Text("Almanca: Ich muss morgen zum Arzt gehen.", fontWeight = FontWeight.SemiBold)
                    Text("Not: 'zum Arzt gehen' günlük kullanım için doğal bir yapı.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        items(scenarios) { item ->
            Card(shape = RoundedCornerShape(22.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item, fontWeight = FontWeight.SemiBold)
                        Text("Konuşma senaryosu", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }
                    Button(onClick = { recording = !recording }) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (recording) "Durdur" else "Başla")
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun ListenScreen() {
    val clips = listOf(
        "Bahnhof anonsu",
        "Market diyaloğu",
        "Doktor randevusu çağrısı",
        "İş görüşmesi tanışma"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1D4ED8))) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Dinleme Pratiği", color = Color(0xFFDBEAFE), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Duy, anla, Türkçe karşılığını bul", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
            }
        }
        items(clips) { clip ->
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(clip, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {}) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Oynat")
                        }
                        AssistChip(onClick = {}, label = { Text("A2") })
                    }
                    Text("Doğru anlamı seç, sonra transcript ve kelime açıklamasını gör.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun TestScreen() {
    val tests = listOf(
        "A1 Mini Test" to "20 soru",
        "A2 Dinleme Testi" to "12 soru",
        "B1 Karma Deneme" to "30 soru"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF7C3AED))) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Sınav Hazırlık", color = Color(0xFFE9D5FF), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("A1-B1 seviye testleri", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
            }
        }
        items(tests) { test ->
            Card(shape = RoundedCornerShape(22.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(test.first, fontWeight = FontWeight.SemiBold)
                        Text(test.second, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(onClick = {}) { Text("Başla") }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun PremiumScreen() {
    val features = listOf(
        "Sınırsız AI öğretmen",
        "Sınırsız konuşma denemesi",
        "Gelişmiş telaffuz geri bildirimi",
        "Tam deneme sınavları",
        "Ayrıntılı hata analizi"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Premium", color = Color(0xFFFDE68A), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Daha fazla konuş, daha hızlı ilerle", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Bu sürümde sadece paketleme ekranı var. Sonraki adım Google Play Billing.", color = Color(0xFFE5E7EB))
                }
            }
        }
        items(features) { feature ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB))) {
                Text(feature, modifier = Modifier.padding(16.dp), fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Text("Premium'a geç")
            }
        }
        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
